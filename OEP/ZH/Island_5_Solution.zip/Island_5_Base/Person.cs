﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class Person
    {
        protected string name;
        protected int strength;
        protected int age;
        protected House? home;

        public int Strength { get => strength; }
        public int Age { get => age; }
        public House? Home { get => home; }

        public Person(string n, int s, int a)
        {
            name = n; strength = s; age = a;
        }

        public void ReduceStrength(int n)
        {
            if (strength <= 0)
                throw new InvalidOperationException("No strength to reduce");
            strength = Math.Max(strength - n, 0);
            if (strength == 0)
                Die();
        }

        public virtual void Die()
        {
            strength = 0;
            Leave();
        }

        public void Leave()
        {
            if (home != null)
            {
                home.Residents.Remove(this);
                home = null;
            }
        }

        public void WorkOnHouse(House h)
        {
            home = h;
            ReduceStrength(3);
        }
    }
}
