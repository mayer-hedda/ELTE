﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class House
    {
        protected int condition;
        private List<Person> residents;

        public int Condition { get => condition; }
        public List<Person> Residents {  get => residents; set => residents = value; }

        public House(List<Person> people)
        {
            condition = 10;
            foreach (Person p in people)
                if (p.Strength == 0 || p.Home != null)
                    throw new InvalidOperationException("A resident building this house is either dead or already has a home");
            residents = people;
            foreach (Person p in residents)
                p.WorkOnHouse(this);
        }

        public void ReduceCondition(int n)
        {
            if (condition == 0)
                return;
            condition = Math.Max(condition - n, 0);
            if (condition == 0)
                Collapse();
        }

        public virtual void Collapse()
        {
            condition = 0;
            List<Person> rs = residents.ToList();
            foreach(Shipwrecked r in rs)
            {
                r.Leave();
                r.ReduceStrength(10);
            }
        }
    }
}
