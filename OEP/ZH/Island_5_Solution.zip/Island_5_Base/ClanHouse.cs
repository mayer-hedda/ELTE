﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class ClanHouse : House
    {
        private Clan clan;

        public ClanHouse(Clan clan) : base(clan.Members)
        {
            clan.House = this;
            this.clan = clan;
        }

        public override void Collapse()
        {
            base.Collapse();
            if(clan.House == this)
            {
                clan.House = null;
            }
        }
    }
}
