﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class Inhabitant : Person
    {
        private Island island;
        private Clan clan;
        public Island Island { get => island; set => island = value; }
        
        public Inhabitant(string n, int s, int a, Clan c, Island i) : base(n, s, a)
        {
            clan = c; island = i;
            i.Inhabitants.Add(this);
        }
        public override void Die()
        {
            base.Die();
            clan.MemberDied(this);
            island.Inhabitants.Remove(this);
        }
    }
}
