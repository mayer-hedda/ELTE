﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal abstract class Island
    {
        protected List<Inhabitant> inhabitants;
        protected List<Shipwrecked> shipwreckeds;
        protected List<House> houses;
        protected List<Clan> clans = new List<Clan>();

        public List<Shipwrecked> Shipwreckeds { get => shipwreckeds; set => shipwreckeds = value; }
        public List<Inhabitant> Inhabitants { get => inhabitants; set => inhabitants = value; }
        public List<Clan> Clans { get => clans; set => clans = value; }
        protected Island()
        {
            shipwreckeds = new List<Shipwrecked>();
            houses = new List<House>();
            inhabitants = new List<Inhabitant>();
        }

        public void Arrive(Shipwrecked person)
        {
            if (shipwreckeds.Contains(person))
                throw new InvalidOperationException("Person already arrived on the island");
            person.Arrive(this);
            shipwreckeds.Add(person);
        }

        public void Build(List<Person> people)
        {
            foreach (Shipwrecked p in people)
                if (!shipwreckeds.Contains(p))
                    throw new InvalidOperationException("Person not on the island cannot build a house there");
            houses.Add(new House(people));
        }

        public void Build(Clan clan)
        {
            if (clan.House != null)
                throw new InvalidOperationException("Clan already has a house");
            House h = new ClanHouse(clan);
            houses.Add(h);
        }

        public virtual void Disaster()
        {
            foreach (Shipwrecked p in shipwreckeds)
                Effect(p);
            foreach (Inhabitant i in inhabitants)
                Effect(i);
            foreach (House h in houses)
                Effect(h);
        }

        protected virtual void Effect(Shipwrecked person) { }
        protected virtual void Effect(Inhabitant person) { }
        protected virtual void Effect(House house) { }
        public (bool, int, Shipwrecked?) WeakestShipwrecked()
        {
            bool l = false;
            int strength = 0;
            Shipwrecked? person = null;
            if (shipwreckeds.Count == 0)
                return (l, strength, person);

            strength = int.MaxValue;
            foreach(Shipwrecked p in shipwreckeds)
            {
                if(p.Strength > 0)
                {
                    l = true;
                    if(p.Strength < strength)
                    {
                        strength = p.Strength;
                        person = p;
                    }
                }
            }
            //person = shipwreckeds.Where(p => p.Strength > 0).MinBy(p => p.Strength);
            return (l, strength, person);
        }

        public void NewClanAppears(string n, List<string> names, List<int> strengths, List<int> ages, JoinRitual j)
        {
            if (names.Count == 0)
                throw new InvalidOperationException("No names given to clan members");
            if (names.Count != strengths.Count || names.Count != ages.Count)
                throw new InvalidOperationException("Lists of inhabitant data don't match in length");

            clans.Add(new Clan(n, names, strengths, ages, this, j));
        }

        public List<string> ClansWithHouse()
        {
            List<string> notHomelessClans = new List<string>();
            foreach (Clan c in clans)
                if (c.House != null)
                    notHomelessClans.Add(c.Name);
            return notHomelessClans;
        }
    }

    class Tropical : Island
    {
        public Tropical() : base() { }
        protected override void Effect(Shipwrecked person)
        {
            if (person.Home == null)
                person.ReduceStrength(3);
        }

        protected override void Effect(Inhabitant person)
        {
            if(person.Home == null)
                person.ReduceStrength(2);
        }

        protected override void Effect(House house)
        {
            house.ReduceCondition(1);
        }
    }

    class Mediterranean : Island
    {
        public Mediterranean() : base() { }

        protected override void Effect(House house)
        {
            house.ReduceCondition(2);
        }
    }

    class Desert : Island
    {
        public Desert() : base() { }
        public override void Disaster()
        {
            (bool b, _, Shipwrecked? person) = WeakestShipwrecked();
            if (b && person != null)
                person.Die();
            foreach(House h in houses)
                Effect(h);
            foreach (Clan clan in clans)
                clan.OldestPersonDies();
        }

        protected override void Effect(House house)
        {
            house.ReduceCondition(1);
        }
    }
}
