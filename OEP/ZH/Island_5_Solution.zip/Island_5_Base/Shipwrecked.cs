﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class Shipwrecked : Person
    {
        private Island? island = null;
        private Clan? clan = null;

        public Island Island { get => island; set => island = value; }
        public Clan Clan { get => clan; set => clan = value; }

        public Shipwrecked(string n, int s, int a) : base(n, s, a) { }
        public void Arrive(Island i)
        {
            island = i;
            ReduceStrength(5);
        }
        public override void Die()
        {
            base.Die();
            if (clan != null)
                clan.MemberDied(this);
            if (island != null)
                island.Shipwreckeds.Remove(this);
        }
    }
}
