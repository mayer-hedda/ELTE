﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class Clan
    {
        private string name;
        private Island island;
        private ClanHouse? house;
        private List<Person> members = new List<Person>();
        private JoinRitual joinRitual;

        public string Name { get => name; }
        public List<Person> Members { get => members; }
        public ClanHouse? House { get => house; set => house = value; }

        public Clan(string n, List<string> names, List<int> strengths, List<int> ages, Island isl, JoinRitual j)
        {
            //változónevek változtak a tervhez képest:
            //  -> Island i és ciklusváltozó i ugyanazon a néven ugyanabban a scopeban
            //  -> az as keyword C#-ban, nem lehet változónév -> a többi lista param hozzáigazítva
            name = n; island = isl; joinRitual = j;
            for (int i = 0; i < names.Count; i++)
                members.Add(new Inhabitant(names[i], strengths[i], ages[i], this, isl));
        }

        public void OldestPersonDies()
        {
            Person? member = null;
            int maxAge = 0;
            foreach (Person m in members)
                if (m.Age > maxAge)
                {
                    member = m;
                    maxAge = m.Age;
                }
            //Person? member = members.MaxBy(m => m.Age);

            if (member != null)
                member.Die();
        }

        public void MemberDied(Person member)
        {
            members.Remove(member);
            if (members.Count == 0)
                island.Clans.Remove(this);
        }

        public void Join(Shipwrecked s)
        {
            if (s.Clan != null)
                throw new InvalidOperationException("Shipwrecked already member of a clan");
            joinRitual.Perform(s, members);
            if (s.Strength > 0)
            {
                members.Add(s);
                s.Clan = this;
            }
        }
    }
}
