﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal abstract class JoinRitual
    {
        protected JoinRitual() { }

        public abstract void Perform(Shipwrecked s, List<Person> members);
    }

    class BloodPact : JoinRitual
    {
        private static BloodPact? instance;
        private BloodPact() : base() { }

        public static BloodPact Instance
        { 
            get {
                instance ??= new BloodPact();
                return instance;
            }
        }
        public override void Perform(Shipwrecked s, List<Person> members)
        {
            foreach (Person m in members)
                m.ReduceStrength(1);
            s.ReduceStrength(1);
        }
    }

    class HuntBeast : JoinRitual
    {
        private static HuntBeast? instance;
        private HuntBeast() : base() { }
        public static HuntBeast Instance
        {
            get
            {
                instance ??= new HuntBeast();
                return instance;
            }
        }

        public override void Perform(Shipwrecked s, List<Person> members)
        {
            s.ReduceStrength(5);
        }
    }
}
