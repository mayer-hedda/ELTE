﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Island_3
{
    internal class Shipwrecked
    {
        private string name;
        private int strength;
        private int age;
        private Island island;
        private House home;

        public int Strength { get => strength; }
        public int Age { get => age; }
        public Island Island { get => island; set => Island = value; }
        public House Home {  get => home; }

        public Shipwrecked(string n, int s, int a)
        {
            name = n; strength = s; age = a;
        }

        public void Arrive(Island i)
        {
            island = i;
            ReduceStrength(5);
        } 

        public void ReduceStrength(int n)
        {
            if (strength <= 0) 
                throw new InvalidOperationException("No strength to reduce");
            strength = Math.Max(strength - n, 0);
            if (strength == 0) 
                Die();
        }

        public void Die()
        {
            strength = 0;
            if (home != null) 
                Leave();
            if (island != null)
                island.Shipwreckeds.Remove(this);
        }

        public void Leave()
        {
            if (home is null)
                throw new InvalidOperationException("No home to leave");
            home.Residents.Remove(this);
            home = null;
        }

        public void WorkOnHouse(House h)
        {
            home = h;
            ReduceStrength(3);
        }
    }
}
