﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_3
{
    internal class House
    {
        private int condition;
        private List<Shipwrecked> residents;

        public int Condition { get => condition; }
        public List<Shipwrecked> Residents {  get => residents; set => residents = value; }

        public House(List<Shipwrecked> people)
        {
            condition = 10;
            foreach (Shipwrecked p in people)
                if (p.Strength == 0 || p.Home != null)
                    throw new InvalidOperationException("A resident building this house is either dead or already has a home");
            residents = people;
            foreach (Shipwrecked p in residents)
                p.WorkOnHouse(this);
        }

        public void ReduceCondition(int n)
        {
            if (condition == 0)
                return;
            condition = Math.Max(condition - n, 0);
            if (condition == 0)
                Collapse();
        }

        public void Collapse()
        {
            condition = 0;
            List<Shipwrecked> rs = residents.ToList();
            foreach(Shipwrecked r in rs)
            {
                r.Leave();
                r.ReduceStrength(10);
            }
        }
    }
}
