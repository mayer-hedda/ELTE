﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Island_3
{
    internal abstract class Island
    {
        protected List<Shipwrecked> shipwreckeds;
        protected List<House> houses;

        public List<Shipwrecked> Shipwreckeds { get => shipwreckeds; set => shipwreckeds = value; }

        protected Island()
        {
            shipwreckeds = new List<Shipwrecked>();
            houses = new List<House>();
        }

        public void Arrive(Shipwrecked person)
        {
            if (shipwreckeds.Contains(person))
                throw new InvalidOperationException("Person already arrived on the island");
            person.Arrive(this);
            shipwreckeds.Add(person);
        }

        public void Build(List<Shipwrecked> people)
        {
            foreach (Shipwrecked p in people)
                if (!shipwreckeds.Contains(p))
                    throw new InvalidOperationException("Person not on the island cannot build a house there");
            houses.Add(new House(people));
        }

        public virtual void Disaster()
        {
            foreach (Shipwrecked p in shipwreckeds)
                Effect(p);
            foreach (House h in houses)
                Effect(h);
        }

        protected virtual void Effect(Shipwrecked person) { }
        protected virtual void Effect(House house) { }
        public (bool, int, Shipwrecked?) WeakestShipwrecked()
        {
            bool l = false;
            int strength = 0;
            Shipwrecked? person = null;
            if (shipwreckeds.Count == 0)
                return (l, strength, person);

            strength = int.MaxValue;
            foreach(Shipwrecked p in shipwreckeds)
            {
                if(p.Strength > 0)
                {
                    l = true;
                    if(p.Strength < strength)
                    {
                        strength = p.Strength;
                        person = p;
                    }
                }
            }
            //person = shipwreckeds.Where(p => p.Strength > 0).MinBy(p => p.Strength);
            return (l, strength, person);
        }
    }

    class Tropical : Island
    {
        public Tropical() : base() { }
        protected override void Effect(Shipwrecked person)
        {
            if (person.Home == null)
                person.ReduceStrength(3);
        }

        protected override void Effect(House house)
        {
            house.ReduceCondition(1);
        }
    }

    class Mediterranean : Island
    {
        public Mediterranean() : base() { }

        protected override void Effect(House house)
        {
            house.ReduceCondition(2);
        }
    }

    class Desert : Island
    {
        public Desert() : base() { }
        public override void Disaster()
        {
            (bool b, _, Shipwrecked? person) = WeakestShipwrecked();
            if (b && person != null)
                person.Die();
            foreach(House h in houses)
                Effect(h);
        }

        protected override void Effect(House house)
        {
            house.ReduceCondition(1);
        }
    }
}
