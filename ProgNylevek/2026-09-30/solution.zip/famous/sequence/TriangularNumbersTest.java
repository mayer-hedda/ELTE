package famous.sequence;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TriangularNumbersTest {
    @Test
    public void test1() {
        assertEquals(0, TriangularNumbers.getTriangularNumber(0));
    }

    @Test
    public void test2() {
        assertEquals(1, TriangularNumbers.getTriangularNumber(1));
    }

    @Test
    public void test3() {
        assertEquals(5050, TriangularNumbers.getTriangularNumber(100));
    }

    @Test
    public void test4() {
        assertEquals(0, TriangularNumbers.getTriangularNumber(-1));
    }

    @Test
    public void test5() {
        assertEquals(0, TriangularNumbers.getTriangularNumber(-50));
    }

    @Test
    public void test6() {
        assertEquals(0, TriangularNumbers.getTriangularNumberAlternative(0));
    }

    @Test
    public void test7() {
        assertEquals(1, TriangularNumbers.getTriangularNumberAlternative(1));
    }

    @Test
    public void test8() {
        assertEquals(5050, TriangularNumbers.getTriangularNumberAlternative(100));
    }

    @Test
    public void test9() {
        assertEquals(0, TriangularNumbers.getTriangularNumberAlternative(-1));
    }

    @Test
    public void test10() {
        assertEquals(0, TriangularNumbers.getTriangularNumberAlternative(-50));
    }
}
