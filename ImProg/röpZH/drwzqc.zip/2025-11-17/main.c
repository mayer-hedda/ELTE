#include <stdio.h>
#include "utils.h"

int main(void) {
    FILE* gandalf = fopen("gandalf.txt", "r");
    if (gandalf == NULL) {
        perror("Error opening file");
        return 1;
    }

    printf(uncoding_ceasar(gandalf));

    return 0;
}
