//
// Created by Mayer Hedda on 2025. 11. 17..
//

#ifndef INC_2025_11_17_UTILS_H
#define INC_2025_11_17_UTILS_H

char* uncoding_ceasar(char* text);

#endif //INC_2025_11_17_UTILS_H